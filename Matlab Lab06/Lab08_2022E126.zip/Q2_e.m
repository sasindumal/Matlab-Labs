%Q2e_2022e126

P1 = phoneRotate(1841);
P2 = phoneRotate(414);
P3 = phoneRotate(-581);
P4 = phoneRotate(-776);

subplot(2,2,1);
imshow(P1);

subplot(2,2,2);
imshow(P2);

subplot(2,2,3);
imshow(P3);

subplot(2,2,4);
imshow(P4);

